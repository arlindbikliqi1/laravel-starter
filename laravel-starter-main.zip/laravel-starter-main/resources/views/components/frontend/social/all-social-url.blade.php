<div class="my-6 flex justify-center space-x-6">
    <x-frontend.social.website_url />
    <x-frontend.social.instagram_url />
    <x-frontend.social.facebook_url />
    <x-frontend.social.twitter_url />
    <x-frontend.social.youtube_url />
    <x-frontend.social.whatsapp_url />
</div>
