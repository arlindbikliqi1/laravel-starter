<img src="{{ asset("img/logo-with-text.jpg") }}" style="height: 50px" />
