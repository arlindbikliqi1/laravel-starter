<?php

return [

    'name' => 'نام',
    'slug' => 'نامک',
    'created_by_alias' => 'نام مستعار نویسنده',
    'intro' => 'معرفی',
    'content' => 'محتوا',
    'image' => 'تصویر',
    'category_id' => 'دسته بندی',
    'type' => 'نوع',
    'is_featured' => 'ویژه است',
    'tags' => 'برچسب ها',
    'status' => 'وضعیت',
    'published_at' => 'منتشر شده در',

    'meta_title' => 'عنوان متا',
    'meta_keywords' => 'کلمات کلیدی متا',
    'meta_description' => 'توضیحات متا',
    'meta_og_image' => 'تصویر متا',
    'meta_og_url' => 'لینک متا',
    'order' => 'ترتیب',

];
